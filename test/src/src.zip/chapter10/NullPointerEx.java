package chapter10;

public class NullPointerEx {

	public static void main(String[] args) {
		String data = null;
		if (data != null) System.out.println(data.toString());

	}

}
