package chapter08;

public interface Action {
	void work();

}
