package chapter08;

public class MySqlDao implements DataAccessObject {

	@Override
	public void select() {
		System.out.println("Mysql DB���� �˻�");
		// TODO Auto-generated method stub

	}

	@Override
	public void insert() {
		System.out.println("Mysql DB�� ����");
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		System.out.println("Mysql DB�� ����");

		// TODO Auto-generated method stub

	}

	@Override
	public void delete() {
		System.out.println("Mysql DB���� ����");

		// TODO Auto-generated method stub

	}

}
