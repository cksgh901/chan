package chapter08;

public interface Soundable {
	String sound();

}
