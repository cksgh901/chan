package chapter08;

public interface InterfaceA {
	public void methodA ();

}
