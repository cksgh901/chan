package chapter08;

public class Dog implements Soundable {

	@Override
	public String sound() {
		return "�۸�";
	}

}
