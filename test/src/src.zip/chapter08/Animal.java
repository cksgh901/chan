package chapter08;

public interface Animal {
	 void eat();
	 void sleep();
	 default void fly() {
		 
	 }

}
