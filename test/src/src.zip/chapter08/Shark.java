package chapter08;

public class Shark implements Animal {

	@Override
	public void eat() {
		System.out.println("�� �Դ´�.");

	}

	@Override
	public void sleep() {
		System.out.println("�� �ܴ�.");

	}

}
