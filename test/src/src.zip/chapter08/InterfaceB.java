package chapter08;

public interface InterfaceB {
	public void methodB();
}
