package oo;

	public class Player {
	    String name;
	    String stone;
	    Player(String name, String stone) {
	        this.name = name;
	        this.stone = stone;
	    }
	}


