package chapter14;

public class AddInpul implements Add {

	@Override
	public int add(int x, int y) {
		// TODO Auto-generated method stub
		return x+y;
	}

}
