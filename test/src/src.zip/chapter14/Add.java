package chapter14;

@FunctionalInterface
public interface Add {
	int add(int x, int y);

}
