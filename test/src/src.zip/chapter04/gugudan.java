package chapter04;

public class gugudan {

	public static void main(String[] args) {
	for ( int j=2; j<=9;j++) {
		System.out.println("["+j+"��]");
		for (int i=1; i<=9; i++) {
			System.out.println(j+" * " +i+" = "+i*j);	
			}
		System.out.println();
		}
	}
}