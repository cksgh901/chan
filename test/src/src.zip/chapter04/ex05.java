package chapter04;

public class ex05 {

	public static void main(String[] args) {
	
		int h = 60;
		
		for(int x=0 ; x<11 ; x++) {
			
			for(int y=0 ; y<11 ; y++) {
				if(x*4+y*5==h) {
					System.out.println("("+x+","+y+")");
		}

	} 
	}

}
}