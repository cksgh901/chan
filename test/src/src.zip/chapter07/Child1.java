package chapter07;

public class Child1 extends Parent1 {
	private int studentNo;
	
	public Child1(String name , int studentNo) {
		super(name);
		this.studentNo = studentNo;

}
}