package chapter07;

public class Taxi extends Vehichle {
	@Override
	public void run() {
		System.out.println("Taix is runnig");
	}
	public void pay() {
		System.out.println("pay to fee");
	}
}
