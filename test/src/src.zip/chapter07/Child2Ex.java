package chapter07;

public class Child2Ex {

	public static void main(String[] args) {
		Child2 child = new Child2();

	}

}
