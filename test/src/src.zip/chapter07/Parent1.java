package chapter07;

public class Parent1 {
	public String name;
	private int studentNo;

	
	public Parent1(String name) {
		this.name = name;
	}
}
