package Chapter09;

public class Person {
	void wake() {
		System.out.println("7�ÿ� �Ͼ�ϴ�.");
	}

}
