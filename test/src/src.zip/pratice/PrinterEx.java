package pratice;

public class PrinterEx {

	public static void main(String[] args) {

		Printer.Printerln(10);
		Printer.Printerln(true);
		Printer.Printerln(5.7);
		Printer.Printerln("ȫ�浿");

	}

}
