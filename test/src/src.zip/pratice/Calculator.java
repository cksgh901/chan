package pratice;

public class Calculator {
	static double pi = 3.14159;
	
	static int puls(int x , int y) {
		return x+y;
	}
	static int minus(int x , int y) {
		return x-y;
	}

}
