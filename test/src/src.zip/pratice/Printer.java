package pratice;

public class Printer {
	
	public Printer() {
		
	}
	 static void Printerln(int Printerln) {
		System.out.println(Printerln);
		
	}
	 static void Printerln(boolean Printerln) {
		System.out.println(Printerln);
	

	}
	 static void Printerln(double Printerln) {
		System.out.println(Printerln);
		
	}
	 static void Printerln(String Printerln) {
		System.out.println(Printerln);
	
	}
}
