package pratice;

public class CarEx {

	public static void main(String[] args) {
		Car mycar = new Car("������");
		Car yourcar = new Car("BMW");

		mycar.run();
		yourcar.run();
	}

}
