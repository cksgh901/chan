package chapter03;

public class exercise05 {

	public static void main(String[] args) {
		int value = 356;
		System.out.println(value - value%100);

	}

}
