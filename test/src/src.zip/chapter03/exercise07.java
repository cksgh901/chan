package chapter03;

public class exercise07 {

	public static void main(String[] args) {
		int lengthTop = 5;
		int lengtBootom = 10;
		int height = 7;
		double area = (lengtBootom+lengthTop)*height/2.0; 
				System.out.println(area);

	}
}
