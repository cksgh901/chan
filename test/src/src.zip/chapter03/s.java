package chapter03;

public class s {

	public static void main(String[] args) {
		int Money = 567000;
				int oman = Money/50000;
				int man = Money%50000/10000;
				int ochun = Money%10000/5000;
				int chun = Money%5000/1000;
				
				System.out.println("5만원권 : "+ oman+ "장" );
				System.out.println("만원권 : "+ man+ "장" );
				System.out.println("5천원권 : "+ ochun+ "장" );
				System.out.println("천원권 : "+ chun+ "장" );

		
		
		
		
				

	}

}
