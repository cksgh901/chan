package chapter06;

public class PrinterEx {

	public static void main(String[] args) {
		
		Prinnter printer = new Prinnter();
		
		Prinnter.println(10);
		Prinnter.println(true);
		Prinnter.println(5.7);
		Prinnter.println("ȫ�浿");

	}

}
