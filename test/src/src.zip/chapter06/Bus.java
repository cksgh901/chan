package chapter06;

public class Bus {
	int speed;
	
	void speedup() {
		speed++;
	}
	
	void speeddown() {
		speed--;
	}
	
	int getSpeed() {
		return speed;
	}
	

}
