package chapter06;

public class Television {
	static String company ="Samsung";
	static String model = "LCD";
	static String info;
	
	static {
		info = company +"-" + model;
	}
 Television() {
	 System.out.println("fuck");
	}
	

}
