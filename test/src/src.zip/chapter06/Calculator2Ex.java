package chapter06;

public class Calculator2Ex {

	public static void main(String[] args) {
		Calculator2 myCalc = new Calculator2();
		myCalc.execute();
		System.out.println("종료");

	}

}
