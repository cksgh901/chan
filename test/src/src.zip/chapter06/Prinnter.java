package chapter06;

public class Prinnter {
	static void println(int a) {
		System.out.println(a);

}
	static void println(boolean a) {
	System.out.println(a);
	}
	static void println(double a ) {
		System.out.println(a);
		
	}
	static void println(String a ) {
		System.out.println(a);
}
}	
	
