package chapter06;

public class TelevisionEx {
	static {
		System.out.println("fff");
	}
	public static void main(String[] args) {
		//System.out.println(Television.info);
		System.out.println("main");
		Television t = new Television();
	}

}
