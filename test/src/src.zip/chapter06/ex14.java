package chapter06;

public class ex14 {
	public static void main(String[] args) {
		ex13 user1 = new ex13("홍길동","hong");
		ex13 user2 = new ex13("강자바","java");
		System.out.println(user1.name+user1.id);
		System.out.println(user2.name+user2.id);


}
}
