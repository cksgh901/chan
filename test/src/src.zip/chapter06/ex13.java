package chapter06;

public class ex13 {
	String name;
	String id;
	String password;
	int age;
	

	ex13(){
	
	
	
}
	ex13(String name){
		this.name = name;
	}
	ex13(String name ,String id){
		this.name = name;
		this.id = id;
	}
}
