package chapter06;

public class Student {
	String name;
	
	public  Student(String name) {
		this.name = name ;
	}
	public  Student(int age) {

}
	public  Student(String name, int age) {
		this.name = name ;
	}
	public  Student( int age, String name) {
}
}
