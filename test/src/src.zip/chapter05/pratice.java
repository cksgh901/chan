package chapter05;

public class pratice {

		  public static void main (String[] args) {
		    // 변수 생성
		    String title = "로미오와 줄리엣";
		    String author = "윌리엄 셰익스피어";
		    double price = 5.94;
		    
		    // 결과 출력
		    System.out.printf("제목: %s\n", title);
		    System.out.printf("저자: %s\n", author);
		    System.out.printf("가격: $%.2f\n", price);
		  }
		}