package chapter05;

public enum Week {
	MONDAY,
	TUSEDAY,
	WEDENSDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY

}
